package app.object;

import java.awt.*;

public interface HasColor {
    Color getColor();
    void setColor(Color color);
}
